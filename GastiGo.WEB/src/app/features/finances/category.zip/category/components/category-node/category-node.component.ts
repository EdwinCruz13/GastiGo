import { CommonModule } from '@angular/common';
import { Component, inject, Input, signal } from '@angular/core';
import { Category } from '@core/models/finances/category.model';
import { ThemeService } from '@core/services/common/theme/theme.service';

@Component({
  selector: 'app-category-node',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './category-node.component.html'
})
export class CategoryNodeComponent { 
  @Input() node!: Category;

  theme = inject(ThemeService)

  expanded = signal(true);

  toggle() {
    this.expanded.update(v => !v);
  }


}
