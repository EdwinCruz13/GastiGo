import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CategoryService } from '@core/services/finances/category.service';
import { Category } from '@core/models/finances/category.model';
import { CategoryNodeComponent } from '@features/finances/category/components/category-node/category-node.component';
import { ModalComponent } from '@shared/components/modal/modal.component';
import { DropdownSelectComponent } from '@shared/components/dropdown-select/dropdown-select.component';

import { NatureService } from '@core/services/finances/nature.service';
import { Nature } from '@core/models/finances/nature.model';

@Component({
  selector: 'app-category-tree',
  standalone: true,
  imports: [CommonModule, CategoryNodeComponent, ModalComponent, DropdownSelectComponent],
  templateUrl: './category-tree.component.html',
  styleUrls: ['./category-tree.component.css']
})
export class CategoryTreeComponent implements OnInit {
  private CategoriaServicio = inject(CategoryService);
  private NaturalezaServicio = inject(NatureService);

  // Señales para almacenar las categorías y naturalezas
  categories = signal<Category[] | null>([]);
  natures = signal<Nature[] | null>([]);


  // Señal para controlar la apertura del modal
  modalOpen = signal(false);

  // Cargar las categorías al inicializar el componente
  ngOnInit() {
    this.CargarCategorias();
    this.CargarNaturalezas();
  }

  // Método para cargar las categorías desde el servicio
  CargarCategorias() {
    this.CategoriaServicio.getTree('{e35452d3-7ff1-4489-8b1d-912e7c6e78fc}')
    .subscribe({
      next: (response) => {
        this.categories.set(response.data);
      },

      //si existe problemas, entonces imprimir mensaje de error en pantalla
      error: (err) => {
        console.log(err)
      }
    });
  }

  // Método para cargar las naturalezas desde el servicio
  CargarNaturalezas() {
      this.NaturalezaServicio.getAll()
      .subscribe({
        next: (response) => {
          this.natures.set(response.data);
          console.log("Naturalezas cargadas:", this.natures())
        },

        //si existe problemas, entonces imprimir mensaje de error en pantalla
        error: (err) => {
          console.log(err)
        }
      });
    }


  // Método para abrir el modal de agregar categoría raíz
  addRootCategory() {
    this.modalOpen.set(true);
  }

  onCategoryChange(value: number) {
    console.log("Categoria seleccionada:", value);
  }
}

