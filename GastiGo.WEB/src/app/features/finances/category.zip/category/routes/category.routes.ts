import { Routes } from '@angular/router';
import { authRedirectGuard } from '@core/guards/auth-redirect.guard';
import { CategoryTreeComponent } from '../components/category-tree/category-tree.component';

export const CATEGORIES_ROUTE: Routes = [
  {
    path: '',
    component: CategoryTreeComponent,
  },

  

];
